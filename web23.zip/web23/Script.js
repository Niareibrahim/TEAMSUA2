document.addEventListener("DOMContentLoaded", function() {
    // Animation de changement de couleur de fond
    function changeBackgroundColor() {
        var colors = ['#ff6347', '#4682b4', '#90ee90']; // Liste de couleurs à utiliser
        var index = 0; // Indice de départ dans la liste des couleurs

        // Fonction pour changer la couleur de fond de manière cyclique
        function animateColor() {
            document.body.style.backgroundColor = colors[index]; // Changer la couleur de fond
            index = (index + 1) % colors.length; // Passer à la prochaine couleur dans la liste
        }

        // Appeler la fonction animateColor toutes les 3 secondes
        setInterval(animateColor, 3000);
    }

    // Appeler la fonction changeBackgroundColor lorsque le document est chargé
    changeBackgroundColor();

    // Fonction pour un jeu simple de devinette de nombre
    var secretNumber = Math.floor(Math.random() * 100) + 1;
    var guess;

    function guessNumber() {
        guess = prompt("Devinez le nombre secret entre 1 et 100:");
        if (guess == secretNumber) {
            alert("Bravo! Vous avez deviné le nombre secret.");
        } else if (guess < secretNumber) {
            alert("Trop bas! Essayez encore.");
        } else if (guess > secretNumber) {
            alert("Trop haut! Essayez encore.");
        }
    }

    // Validation du formulaire de contact
    var contactForm = document.getElementById('contact-form');

    contactForm.addEventListener('submit', function(event) {
        event.preventDefault(); // Empêcher l'envoi par défaut du formulaire

        // Récupération des valeurs des champs
        var nom = document.getElementById('nom').value;
        var email = document.getElementById('email').value;
        var message = document.getElementById('message').value;

        // Vérification des champs requis
        if (nom.trim() === '' || email.trim() === '' || message.trim() === '') {
            alert('Veuillez remplir tous les champs du formulaire.');
            return;
        }

        // Envoi des données (simulé ici)
        alert('Formulaire soumis avec succès !');
        contactForm.reset(); // Réinitialiser le formulaire
    });

    // Afficher ou masquer le bouton de retour en haut de page en fonction du défilement
    window.addEventListener('scroll', function() {
        var backToTopButton = document.querySelector('.back-to-top');
        if (window.scrollY > 300) {
            backToTopButton.style.display = 'block';
        } else {
            backToTopButton.style.display = 'none';
        }
    });

    // Sélectionner le bouton de retour en haut de page
    var backToTopButton = document.querySelector('.back-to-top');

    // Ajouter un écouteur d'événements pour le clic sur le bouton
    backToTopButton.addEventListener('click', function() {
        // Faire défiler la page vers le haut avec une animation fluide
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });

    // Navigation à défilement fluide
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();

            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });

    // Animation du jeu
    const startButton = document.getElementById("start-animation");
    const animationContainer = document.getElementById("animation-container");

    startButton.addEventListener("click", function() {
        startButton.style.display = "none"; // Cacher le bouton de démarrage
        animationContainer.style.display = "block"; // Afficher la zone d'animation

        // Création de l'animation
        let animationFrame = 0;
        const animationFrames = [
            "🌟",
            "✨",
            "💫",
            "🌠",
            "🎇"
            // Ajoutez d'autres cadres d'animation si nécessaire
        ];

        const animationInterval = setInterval(function() {
            animationContainer.textContent = animationFrames[animationFrame];
            animationFrame++;

            if (animationFrame >= animationFrames.length) {
                animationFrame = 0; // Réinitialiser le compteur pour boucler l'animation
            }
        }, 500); // Vitesse de l'animation en millisecondes (500ms = 0.5s)

        // Arrêter l'animation après un certain temps (par exemple, 5 secondes)
        setTimeout(function() {
            clearInterval(animationInterval); // Arrêter l'intervalle de l'animation
            animationContainer.textContent = "Le jeu est terminé!"; // Message de fin
        }, 5000); // Durée totale de l'animation en millisecondes (5000ms = 5s)
    });

    // Défilement automatique des images
    var currentIndex = 0;
    var images = document.querySelectorAll('#accueil .slider img');

    function nextImage() {
        images[currentIndex].style.display = 'none';
        currentIndex = (currentIndex + 1) % images.length;
        images[currentIndex].style.display = 'block';
    }

    setInterval(nextImage, 3000); // Défilement automatique toutes les 3 secondes
});